import {React, useState, useEffect} from "react";
import "./APIfetch.css";

const APIfetch = ({keyword}) => {
    const [items,setItems] = useState([]);
    const [dataLoaded, setDataLoaded] = useState(true);
    useEffect(() => {
        fetch(`https://api.tcgdex.net/v2/en/cards/${keyword}`)
        .then((res) => res.json())
        .then((json) => {
            setItems(json);
            setDataLoaded(true);
        });
    });
        return (
                <div className="App">
                    <h1 className="pokeFetch">TCGdev card</h1>
                    <div className="container">
                        {dataLoaded && items && (
                            <div className="item">
                                <ul>
                                    <li><strong>ID:</strong> {items.id}</li>
                                    <li><strong>Name:</strong> {items.name}</li>
                                </ul>
                                {items.image && (
                                    <img src={items.image + "/high.png"} alt={items.name} />
                                )}
                            </div>
                        )}
                    </div>
                </div>
            );
};
export default APIfetch;